//
//  NoteDetailController.h
//  Voice2Note
//
//  Created by liaojinxing on 14-6-11.
//  Copyright (c) 2014年 jinxing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VNNote.h"

@interface NoteDetailController : UIViewController

- (instancetype)initWithNote:(VNNote *)note;

@end
